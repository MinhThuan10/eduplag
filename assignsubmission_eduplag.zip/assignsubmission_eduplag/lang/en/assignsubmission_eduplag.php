<?php

$string['eduplag'] = 'EduPlag plagiarism checker';
$string['checkplagiarism'] = 'Check for plagiarism';
$string['checkplagiarism_help'] = 'Enable automatic plagiarism checking via EduPlag.';
$string['viewstudent'] = 'Allow students to view plagiarism score';
$string['viewstudent_help'] = 'Show students their plagiarism result if available.';
$string['pluginname'] = 'EduPlag submission';
$string['schoolkey'] = 'School Key';
$string['schoolkey_desc'] = 'The school_key used to link this Moodle instance to a school in Eduplag';
$string['plagiarism'] = 'Plagiarism Score';
$string['urlfilechecked'] = 'Report File Checked';
$string['checkedfile'] = 'Checked File';
$string['reportlink'] = 'View Report';
